Pominmy testy [skip tests]
